"""Generated from version.json; do not edit."""
VERSION = '2026.10.19.54'
HELPER_BUILD = 54
