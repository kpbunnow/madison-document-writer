# Madison Building Inspection R53

Install the complete deploy folder using its Start Document Writer - READ ME.md. Before the first installation, IT checks the deploy ZIP's SHA-256 against the value the release owner publishes separately. After that, inspectors use the installed desktop shortcut; each update is checked file by file against runtime-manifest.json. The deployment folder must be writable only by the release owner.

Source is maintained under source/ with one version.json. Verification is in the matching evidence ZIP. The manual is in deploy/PROGRAM-MANUAL.html and its Word/PDF editions. City acceptance remains open in the acceptance record; no live rollout has been performed.
